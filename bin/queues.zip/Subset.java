import java.util.Iterator;

public class Subset 
{
	public static void main( String[] args ) {
		//int sizeOfRandQ = StdIn.readInt();
		//int counter = 0;
		RandomizedQueue< String > randQ = new RandomizedQueue<String>();
		while( !StdIn.isEmpty() ) {
			/*String item  = StdIn.readString();
			if( counter++ < sizeOfRandQ ) {
				randQ.enqueue(item);
			}else{
				randQ.dequeue();
				randQ.enqueue(item);
			}*/
			randQ.enqueue( StdIn.readString());
		} //while()
		int sizeOfRandQ = Integer.parseInt(args[0]);
		int counter = 0;
		Iterator< String > iter = randQ.iterator();
		while( iter.hasNext() && ( counter++ < sizeOfRandQ ) ) {
			System.out.println( iter.next() );
		}
	} //main ! 
	
	/*public static void main(String[] args) {
        
        int n = 0;
        String[] strings = new String[1];
        
        while (!StdIn.isEmpty()) {
            String s = StdIn.readString();
            
            strings[n++] = s;
            
            if (n == strings.length) {
                String[] newStrings = new String[n * 2];
                
                for (int i = 0; i < n; i++) {
                    newStrings[i] = strings[i];
                }
                
                strings = newStrings;
            }
            
            int r = StdRandom.uniform(n);
            
            String swap = strings[n-1];
            strings[n-1] = strings[r];
            strings[r] = swap;
        }
        
        int k = Integer.parseInt(args[0]);
        
        for (int i = 0; i < k && i < n; i++) {
            StdOut.println(strings[i]);
        }
    }*/
} //class:Subset !
